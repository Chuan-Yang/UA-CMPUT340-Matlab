load char_c1.mat;
ComputeTomography(Achar,Bchar,imsize);

function ComputeTomography(Achar,Bchar,imsize)
    [~,n]=size(Bchar);
    for i = 1:n
        graph = reshape(Achar\(Bchar(:,i)),imsize);
        graph = graph';
        subplot(1,n,i);
        imshow(graph);
    end
end